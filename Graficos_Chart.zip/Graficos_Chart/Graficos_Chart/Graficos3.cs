﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization;
using System.Windows.Forms.DataVisualization.Charting;

namespace Graficos_Chart
{
    public partial class Graficos3 : Form
    {
        public Graficos3()
        {
            InitializeComponent();
        }

        private void Graficos3_Load(object sender, EventArgs e)
        {
            // Propriedades do Chart:
            // Legends: Remove
            // Series: Remove
        }

        private void btnGerar_Click(object sender, EventArgs e)
        {
            GerarGrafico();
        }

        private void GerarGrafico()
        {
            short AnoInformado = Convert.ToInt16(numAno.Value);
            var vendas = new Vendas();
            var lista = vendas.VendasAnual(AnoInformado);

            var setores = vendas.GetNomeSetores(lista);
            var valores = vendas.GetValoresSetores(lista);

            try
            {      
                // Titulo Principal
                var titulo = new Title();
                titulo.Font = new Font("Elephant", 22, FontStyle.Bold);
                titulo.ForeColor = Color.DarkBlue;
                titulo.Text = "Vendas do ano  de " + lista[0].Ano.ToString();
                chart1.Titles.Add(titulo);

                // Título secundário
                var titulo2 = new Title();
                titulo.Font = new Font("Arial", 18, FontStyle.Bold);
                titulo.ForeColor = Color.DarkRed;
                titulo2.Text = "Valores em reais";
                chart1.Titles.Add(titulo2);

                // Inserir Legenda
                chart1.Legends.Add("Legenda");
                chart1.Legends[0].Title = "Setores"; // Setores é o array. Construtor que foi criado com parâmetros.

                chart1.Series.Add("Vendas");
                chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;

                // Mostrar os valores sobre as fatias da pizza
                chart1.Series[0].IsValueShownAsLabel = true;

                // Inclinação e rotação do gráfico
                chart1.ChartAreas[0].Area3DStyle.Enable3D = true;
                chart1.ChartAreas[0].Area3DStyle.Inclination = 30;
                chart1.ChartAreas[0].Area3DStyle.Rotation = 60;

                // Paleta de cores
                chart1.Palette = ChartColorPalette.SemiTransparent;

                // Série de dados com os valores do gráfico
                chart1.Series[0].Points.DataBindXY(setores, valores);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            btnGerar.Enabled = true;
            // Limpa todas as séries do controle Chart
            //chart1.Series.Clear();
            //chart1.Titles.Clear();
            //chart1.Legends.Clear();
            //chart1.ChartAreas.Clear();
            Graficos3 form = new Graficos3();

            // Fecha este form
            this.Close();
            // Exibe este form
            form.ShowDialog();
        }
    }
}
