﻿
namespace Graficos_Chart
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExemplo3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExemplo3
            // 
            this.btnExemplo3.Location = new System.Drawing.Point(265, 43);
            this.btnExemplo3.Name = "btnExemplo3";
            this.btnExemplo3.Size = new System.Drawing.Size(99, 50);
            this.btnExemplo3.TabIndex = 2;
            this.btnExemplo3.Text = "Exemplo";
            this.btnExemplo3.UseVisualStyleBackColor = true;
            this.btnExemplo3.Click += new System.EventHandler(this.btnExemplo3_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 150);
            this.Controls.Add(this.btnExemplo3);
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnExemplo3;
    }
}