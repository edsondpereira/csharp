﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Graficos_Chart
{
    class Vendas
    {
        SqlCommand cmd = new SqlCommand();//Faz referencia ao SqlClient.
        StringBuilder sql = new StringBuilder();//Inclui tudo no no banco.
        DataTable dt = new DataTable();//Faz referencia ao Data.

        public string Setor { get; set; }
        public Decimal Valor { get; set; }
        public short Ano { get; set; }

        // Abaixo foi criado o construtor da classe Vendas, com parâmetros
        public Vendas(short ano, string setor, decimal valor)
        {
            this.Ano = ano;
            this.Setor = setor;
            this.Valor = valor;
        }

        public Vendas() // Construtor padrão
        {

        }

        // Construtor que substitui o acima
        public List<Vendas> VendasAnual(short ano)
        {
            var vendasSetor = new List<Vendas>();

            using (SqlConnection conexao = new SqlConnection(clsConexao.stringConexao))
            {
                string query = "SELECT Setor, Valor FROM tbVendas WHERE Ano = @Ano";
                SqlCommand cmd = new SqlCommand(query, conexao);
                cmd.Parameters.AddWithValue("@Ano", ano);
                conexao.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string setor = reader["Setor"].ToString();
                    decimal valor = Convert.ToDecimal(reader["Valor"]);
                    vendasSetor.Add(new Vendas(ano, setor, valor));
                }

            }
            return vendasSetor;
        }

        public string[] GetNomeSetores(List<Vendas> vendas)
        {
            string[] setores = new string[vendas.Count];

            for (int i = 0; i < vendas.Count; i++)
            {
                setores[i] = vendas[i].Setor;
            }
            return setores;
        }

        public decimal[] GetValoresSetores(List<Vendas> vendas)
        {
            decimal[] valores = new decimal[vendas.Count];

            for (int i = 0; i < vendas.Count; i++)
            {
                valores[i] = vendas[i].Valor;
            }
            return valores;
        }

    }

}

