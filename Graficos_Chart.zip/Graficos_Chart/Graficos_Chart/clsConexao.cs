﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graficos_Chart
{
    public class clsConexao
    {
        //private static string conexao = @"Data Source=.\SQLEXPRESS; Initial Catalog=bdComissao; user id=sa; password=sa";
        private static string conexao = @"Data Source=.\SQLEXPRESS; Initial Catalog=bdVendas; Integrated Security=True";
        public static string stringConexao
        {
            get { return conexao; }
        }

    }
}
