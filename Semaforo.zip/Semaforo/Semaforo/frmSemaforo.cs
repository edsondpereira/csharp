﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Semaforo
{
    public partial class frmSemaforo : Form
    {
        int segundo = 0;
        public frmSemaforo()
        {
            InitializeComponent();
        }

        private void btnDesligar_Click(object sender, EventArgs e)
        {
            tmrSemaforo.Enabled = false; // Desliga o semáforo
            lblSemaforo.Text = "Desligado";
        }

        private void tmrTempo_Tick(object sender, EventArgs e)
        {            
            lblSegundos.Text = segundo.ToString();
            segundo++;
            if (segundo > 29)
            {
                segundo = 0;
            }
        }

        private void btnLigar_Click(object sender, EventArgs e)
        {
            tmrTempo.Enabled = true; // Ligar o timer que controla o tempo
        }
    }
}
