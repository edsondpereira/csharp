﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_Soma_2Numeros
{
    internal class clsSoma
    {
        private int numero1; // Definição do atributo numero1
        private int numero2; // Definição do atributo numero2

        // Propriedades públicas para ter acesso aos atributos acima
        public int Numero1
        {
            get { return numero1; }
            set { numero1 = value; }
        }

        public int Numero2
        {
            get { return numero2; }
            set { numero2 = value; }
        }

        // Método para realizar a soma
        public int Somar(int numero1, int numero2)
        {
            return numero1 + numero2;
        }
    }
}
