﻿namespace Calculo_Salario
{
    partial class frmSalario
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbDados = new System.Windows.Forms.GroupBox();
            this.txtPercentualAumento = new System.Windows.Forms.TextBox();
            this.lblPercentualAumento = new System.Windows.Forms.Label();
            this.txtSalarioBruto = new System.Windows.Forms.TextBox();
            this.cmbCargo = new System.Windows.Forms.ComboBox();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblCargo = new System.Windows.Forms.Label();
            this.txtFuncionario = new System.Windows.Forms.TextBox();
            this.lblFuncionario = new System.Windows.Forms.Label();
            this.grbOpcoes = new System.Windows.Forms.GroupBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnExibir = new System.Windows.Forms.Button();
            this.grbResultado = new System.Windows.Forms.GroupBox();
            this.lblSalarioReceber = new System.Windows.Forms.Label();
            this.lblAumentoConcedido = new System.Windows.Forms.Label();
            this.btnNovo = new System.Windows.Forms.Button();
            this.grbDados.SuspendLayout();
            this.grbOpcoes.SuspendLayout();
            this.grbResultado.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbDados
            // 
            this.grbDados.Controls.Add(this.txtPercentualAumento);
            this.grbDados.Controls.Add(this.lblPercentualAumento);
            this.grbDados.Controls.Add(this.txtSalarioBruto);
            this.grbDados.Controls.Add(this.cmbCargo);
            this.grbDados.Controls.Add(this.lblSalarioBruto);
            this.grbDados.Controls.Add(this.lblCargo);
            this.grbDados.Controls.Add(this.txtFuncionario);
            this.grbDados.Controls.Add(this.lblFuncionario);
            this.grbDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbDados.Location = new System.Drawing.Point(11, 8);
            this.grbDados.Name = "grbDados";
            this.grbDados.Size = new System.Drawing.Size(387, 181);
            this.grbDados.TabIndex = 0;
            this.grbDados.TabStop = false;
            this.grbDados.Text = "Dados";
            // 
            // txtPercentualAumento
            // 
            this.txtPercentualAumento.Location = new System.Drawing.Point(185, 143);
            this.txtPercentualAumento.Name = "txtPercentualAumento";
            this.txtPercentualAumento.Size = new System.Drawing.Size(77, 23);
            this.txtPercentualAumento.TabIndex = 6;
            // 
            // lblPercentualAumento
            // 
            this.lblPercentualAumento.AutoSize = true;
            this.lblPercentualAumento.Location = new System.Drawing.Point(185, 123);
            this.lblPercentualAumento.Name = "lblPercentualAumento";
            this.lblPercentualAumento.Size = new System.Drawing.Size(103, 17);
            this.lblPercentualAumento.TabIndex = 5;
            this.lblPercentualAumento.Text = "% de aumento:";
            // 
            // txtSalarioBruto
            // 
            this.txtSalarioBruto.Location = new System.Drawing.Point(18, 143);
            this.txtSalarioBruto.Name = "txtSalarioBruto";
            this.txtSalarioBruto.Size = new System.Drawing.Size(71, 23);
            this.txtSalarioBruto.TabIndex = 4;
            // 
            // cmbCargo
            // 
            this.cmbCargo.FormattingEnabled = true;
            this.cmbCargo.Location = new System.Drawing.Point(18, 86);
            this.cmbCargo.Name = "cmbCargo";
            this.cmbCargo.Size = new System.Drawing.Size(261, 24);
            this.cmbCargo.TabIndex = 3;
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Location = new System.Drawing.Point(18, 122);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(93, 17);
            this.lblSalarioBruto.TabIndex = 2;
            this.lblSalarioBruto.Text = "Salário bruto:";
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Location = new System.Drawing.Point(15, 66);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(50, 17);
            this.lblCargo.TabIndex = 2;
            this.lblCargo.Text = "Cargo:";
            // 
            // txtFuncionario
            // 
            this.txtFuncionario.Location = new System.Drawing.Point(18, 39);
            this.txtFuncionario.Name = "txtFuncionario";
            this.txtFuncionario.Size = new System.Drawing.Size(324, 23);
            this.txtFuncionario.TabIndex = 1;
            this.txtFuncionario.Enter += new System.EventHandler(this.txtFuncionario_Enter);
            // 
            // lblFuncionario
            // 
            this.lblFuncionario.AutoSize = true;
            this.lblFuncionario.Location = new System.Drawing.Point(18, 21);
            this.lblFuncionario.Name = "lblFuncionario";
            this.lblFuncionario.Size = new System.Drawing.Size(143, 17);
            this.lblFuncionario.TabIndex = 0;
            this.lblFuncionario.Text = "Nome do funcionário:";
            // 
            // grbOpcoes
            // 
            this.grbOpcoes.Controls.Add(this.btnNovo);
            this.grbOpcoes.Controls.Add(this.btnSair);
            this.grbOpcoes.Controls.Add(this.btnExibir);
            this.grbOpcoes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbOpcoes.Location = new System.Drawing.Point(66, 197);
            this.grbOpcoes.Name = "grbOpcoes";
            this.grbOpcoes.Size = new System.Drawing.Size(288, 77);
            this.grbOpcoes.TabIndex = 1;
            this.grbOpcoes.TabStop = false;
            this.grbOpcoes.Text = "Opções";
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(188, 15);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(86, 53);
            this.btnSair.TabIndex = 0;
            this.btnSair.Text = "Sai&r";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnExibir
            // 
            this.btnExibir.Location = new System.Drawing.Point(11, 15);
            this.btnExibir.Name = "btnExibir";
            this.btnExibir.Size = new System.Drawing.Size(86, 53);
            this.btnExibir.TabIndex = 0;
            this.btnExibir.Text = "&Exibir";
            this.btnExibir.UseVisualStyleBackColor = true;
            this.btnExibir.Click += new System.EventHandler(this.btnExibir_Click);
            // 
            // grbResultado
            // 
            this.grbResultado.Controls.Add(this.lblSalarioReceber);
            this.grbResultado.Controls.Add(this.lblAumentoConcedido);
            this.grbResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbResultado.Location = new System.Drawing.Point(61, 279);
            this.grbResultado.Name = "grbResultado";
            this.grbResultado.Size = new System.Drawing.Size(293, 77);
            this.grbResultado.TabIndex = 2;
            this.grbResultado.TabStop = false;
            this.grbResultado.Text = "Resultado";
            // 
            // lblSalarioReceber
            // 
            this.lblSalarioReceber.AutoSize = true;
            this.lblSalarioReceber.Location = new System.Drawing.Point(13, 52);
            this.lblSalarioReceber.Name = "lblSalarioReceber";
            this.lblSalarioReceber.Size = new System.Drawing.Size(198, 17);
            this.lblSalarioReceber.TabIndex = 0;
            this.lblSalarioReceber.Text = "O salário com o aumento é de";
            // 
            // lblAumentoConcedido
            // 
            this.lblAumentoConcedido.AutoSize = true;
            this.lblAumentoConcedido.Location = new System.Drawing.Point(13, 20);
            this.lblAumentoConcedido.Name = "lblAumentoConcedido";
            this.lblAumentoConcedido.Size = new System.Drawing.Size(174, 17);
            this.lblAumentoConcedido.TabIndex = 0;
            this.lblAumentoConcedido.Text = "O aumento concedido foi  ";
            // 
            // btnNovo
            // 
            this.btnNovo.Location = new System.Drawing.Point(99, 15);
            this.btnNovo.Name = "btnNovo";
            this.btnNovo.Size = new System.Drawing.Size(86, 53);
            this.btnNovo.TabIndex = 1;
            this.btnNovo.Text = "&Novo";
            this.btnNovo.UseVisualStyleBackColor = true;
            this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            // 
            // frmSalario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 365);
            this.Controls.Add(this.grbResultado);
            this.Controls.Add(this.grbOpcoes);
            this.Controls.Add(this.grbDados);
            this.MaximizeBox = false;
            this.Name = "frmSalario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calcula o salário do funcionário";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSalario_FormClosing);
            this.Load += new System.EventHandler(this.frmSalario_Load);
            this.grbDados.ResumeLayout(false);
            this.grbDados.PerformLayout();
            this.grbOpcoes.ResumeLayout(false);
            this.grbResultado.ResumeLayout(false);
            this.grbResultado.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbDados;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.TextBox txtFuncionario;
        private System.Windows.Forms.Label lblFuncionario;
        private System.Windows.Forms.TextBox txtPercentualAumento;
        private System.Windows.Forms.Label lblPercentualAumento;
        private System.Windows.Forms.TextBox txtSalarioBruto;
        private System.Windows.Forms.ComboBox cmbCargo;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.GroupBox grbOpcoes;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnExibir;
        private System.Windows.Forms.GroupBox grbResultado;
        private System.Windows.Forms.Label lblSalarioReceber;
        private System.Windows.Forms.Label lblAumentoConcedido;
        private System.Windows.Forms.Button btnNovo;
    }
}

