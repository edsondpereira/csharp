﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculo_Salario
{
    public partial class frmSalario : Form
    {
        public frmSalario()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmSalario_Load(object sender, EventArgs e)
        {           
            // Preenche o combobox
            cmbCargo.Items.Add("Analista");
            cmbCargo.Items.Add("Programador");
            cmbCargo.Items.Add("Gerente");
            cmbCargo.Items.Add("CEO");
        }

        private void btnExibir_Click(object sender, EventArgs e)
        {
            double SalarioBruto = 0, PercentualAumento = 0, AumentoConcedido = 0, SalarioReceber = 0;

            // Tenta converter o salário.
            bool ESalario = double.TryParse(txtSalarioBruto.Text, out SalarioBruto);
            if (!ESalario) // Senão conseguiu converter
            {
                MessageBox.Show("Por favor... informe um salário válido!");
                txtSalarioBruto.Focus();
                return;
            }

            bool EPercentual = double.TryParse(txtPercentualAumento.Text, out PercentualAumento);
            if (!EPercentual) // Senão conseguiu converter
            {
                MessageBox.Show("Por favor... informe um % de aumento válido!");
                txtPercentualAumento.Focus();
                return;
            }

            // Calcula o valor do aumento

            SalarioBruto = Convert.ToDouble(txtSalarioBruto.Text);
            PercentualAumento = Convert.ToDouble(txtPercentualAumento.Text);
            AumentoConcedido = (SalarioBruto * PercentualAumento) / 100;
            lblAumentoConcedido.Text = "O aumento concedido foi " + AumentoConcedido;

            // Calcula o salário a receber com o valor do aumento
            SalarioReceber = SalarioBruto + AumentoConcedido;
            lblSalarioReceber.Text = "O salário com o aumento é de " + SalarioReceber;

            btnExibir.Enabled = false;
            btnNovo.Enabled = true;
        }

        private void frmSalario_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show("Não esqueça de fazer backup!");
        }

        private void Limpar()
        {
            txtFuncionario.Clear();
            cmbCargo.SelectedIndex = -1;
            txtSalarioBruto.Clear();
            txtPercentualAumento.Clear();
            lblAumentoConcedido.Text = "";
            lblSalarioReceber.Text = "";
        }

        private void txtFuncionario_Enter(object sender, EventArgs e)
        {
           
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            Limpar(); // Carrega o método Limpar
            btnExibir.Enabled = true;
            btnNovo.Enabled = false;
        }
    }
}
