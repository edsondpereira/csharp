﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO; // Esta biblioteca permite o uso do método abaixo:  Directory.GetCurrentDirectory() --> Ele obtém o diretório atual da aplicação

namespace Tabuada
{
    public partial class frmTabuada : Form
    {
        int primeiro, segundo;
        int pontosComputador, pontosVoce;
        public frmTabuada()
        {
            InitializeComponent();
        }

        private void frmTabuada_Load(object sender, EventArgs e)
        {
            sorteia(); // Chama o método que sorteia o primeiro e o segundo número da tabuada
        }

        private void sorteia()
        {
            Random Randomico = new Random();
            primeiro = Randomico.Next(10) + 1; // Sorteia o primeiro número entre 1 e 10
            segundo = Randomico.Next(10) + 1; // Sorteia o segundo número entre 1 e 10

            lblNumero1.Text = primeiro.ToString(); // Exibe o primeiro número
            lblNumero2.Text = segundo.ToString(); // Exibe o segundo número
            // O método ToString é necessário pois a variável é inteira e o label é string
        }

        private void btnSorteia_Click(object sender, EventArgs e)
        {
            btnSorteia.Enabled = false; 
            sorteia();
            txtResultado.Text = ""; // Apaga o resultado digitado
            txtResultado.Focus(); // Coloca o foco (cursor) nesta caixa
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            string dirAtual = Directory.GetCurrentDirectory(); // Armazena na variável dirAtual, onde está pasta debug (onde o aplicativo é compilado), ou seja o caminho
            if ((primeiro * segundo) == Convert.ToInt16(txtResultado.Text))
            {
                picRosto.Image = Properties.Resources.parabens; // Exibe a imagem no picturebox
            }
            else
            {
                pontosComputador += 1; // Acumula os pontos do computador
                picRosto.ImageLocation = dirAtual + @"\imagens\lamento.jpg";
            }

            // Exibe os pontos
            lblPontosComputador.Text = pontosComputador.ToString();
            lblPontosVoce.Text = pontosVoce.ToString();

            lblMensagem.Text = "Clique no botão Sorteio para continuar!";
        }

        private void txtResultado_Enter(object sender, EventArgs e)
        {
            lblMensagem.Text = "Digite o resultado e clique no botão Verifica";
        }
    }
}
