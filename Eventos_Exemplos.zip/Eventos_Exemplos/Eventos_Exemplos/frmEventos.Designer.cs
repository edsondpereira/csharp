﻿namespace Eventos_Exemplos
{
    partial class frmEventos
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblChange = new System.Windows.Forms.Label();
            this.txtChange = new System.Windows.Forms.TextBox();
            this.lblMostrar = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lbleventoEnter = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lbldataNascimento = new System.Windows.Forms.Label();
            this.mskdataNascimento = new System.Windows.Forms.MaskedTextBox();
            this.lblIdade = new System.Windows.Forms.Label();
            this.txtIdade = new System.Windows.Forms.TextBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.lblOK = new System.Windows.Forms.Label();
            this.picFoto = new System.Windows.Forms.PictureBox();
            this.lblSexo = new System.Windows.Forms.Label();
            this.txtSexo = new System.Windows.Forms.TextBox();
            this.lblTeclas = new System.Windows.Forms.Label();
            this.btnRecortar = new System.Windows.Forms.Button();
            this.btnCopiar = new System.Windows.Forms.Button();
            this.btnColar = new System.Windows.Forms.Button();
            this.btnOcultar = new System.Windows.Forms.Button();
            this.btnMostrar = new System.Windows.Forms.Button();
            this.lblMostrar2 = new System.Windows.Forms.Label();
            this.btnImagem = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).BeginInit();
            this.SuspendLayout();
            // 
            // lblChange
            // 
            this.lblChange.AutoSize = true;
            this.lblChange.Location = new System.Drawing.Point(16, 14);
            this.lblChange.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(105, 17);
            this.lblChange.TabIndex = 0;
            this.lblChange.Text = "Evento Change";
            // 
            // txtChange
            // 
            this.txtChange.Location = new System.Drawing.Point(20, 33);
            this.txtChange.Margin = new System.Windows.Forms.Padding(4);
            this.txtChange.Name = "txtChange";
            this.txtChange.Size = new System.Drawing.Size(531, 22);
            this.txtChange.TabIndex = 1;
            // 
            // lblMostrar
            // 
            this.lblMostrar.AutoSize = true;
            this.lblMostrar.Location = new System.Drawing.Point(20, 359);
            this.lblMostrar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMostrar.Name = "lblMostrar";
            this.lblMostrar.Size = new System.Drawing.Size(0, 17);
            this.lblMostrar.TabIndex = 2;
            // 
            // txtNome
            // 
            this.txtNome.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNome.Location = new System.Drawing.Point(24, 117);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(531, 22);
            this.txtNome.TabIndex = 4;            
            // 
            // lbleventoEnter
            // 
            this.lbleventoEnter.AutoSize = true;
            this.lbleventoEnter.Location = new System.Drawing.Point(20, 73);
            this.lbleventoEnter.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbleventoEnter.Name = "lbleventoEnter";
            this.lbleventoEnter.Size = new System.Drawing.Size(90, 17);
            this.lbleventoEnter.TabIndex = 3;
            this.lbleventoEnter.Text = "Evento Enter";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(23, 97);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(49, 17);
            this.lblNome.TabIndex = 5;
            this.lblNome.Text = "Nome:";
            // 
            // lbldataNascimento
            // 
            this.lbldataNascimento.AutoSize = true;
            this.lbldataNascimento.Location = new System.Drawing.Point(25, 150);
            this.lbldataNascimento.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbldataNascimento.Name = "lbldataNascimento";
            this.lbldataNascimento.Size = new System.Drawing.Size(124, 17);
            this.lbldataNascimento.TabIndex = 7;
            this.lbldataNascimento.Text = "Dt de Nascimento:";
            // 
            // mskdataNascimento
            // 
            this.mskdataNascimento.Location = new System.Drawing.Point(27, 170);
            this.mskdataNascimento.Margin = new System.Windows.Forms.Padding(4);
            this.mskdataNascimento.Mask = "00/00/0000";
            this.mskdataNascimento.Name = "mskdataNascimento";
            this.mskdataNascimento.Size = new System.Drawing.Size(124, 22);
            this.mskdataNascimento.TabIndex = 8;
            this.mskdataNascimento.ValidatingType = typeof(System.DateTime);
            // 
            // lblIdade
            // 
            this.lblIdade.AutoSize = true;
            this.lblIdade.Location = new System.Drawing.Point(159, 150);
            this.lblIdade.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIdade.Name = "lblIdade";
            this.lblIdade.Size = new System.Drawing.Size(47, 17);
            this.lblIdade.TabIndex = 10;
            this.lblIdade.Text = "Idade:";
            // 
            // txtIdade
            // 
            this.txtIdade.Location = new System.Drawing.Point(160, 170);
            this.txtIdade.Margin = new System.Windows.Forms.Padding(4);
            this.txtIdade.Name = "txtIdade";
            this.txtIdade.Size = new System.Drawing.Size(131, 22);
            this.txtIdade.TabIndex = 9;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(55, 222);
            this.btnOK.Margin = new System.Windows.Forms.Padding(4);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(128, 52);
            this.btnOK.TabIndex = 11;
            this.btnOK.Text = "Evento Click";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // lblOK
            // 
            this.lblOK.AutoSize = true;
            this.lblOK.Location = new System.Drawing.Point(51, 277);
            this.lblOK.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOK.Name = "lblOK";
            this.lblOK.Size = new System.Drawing.Size(133, 17);
            this.lblOK.TabIndex = 12;
            this.lblOK.Text = "Confirma as opções";
            this.lblOK.Visible = false;
            // 
            // picFoto
            // 
            this.picFoto.Location = new System.Drawing.Point(347, 218);
            this.picFoto.Margin = new System.Windows.Forms.Padding(4);
            this.picFoto.Name = "picFoto";
            this.picFoto.Size = new System.Drawing.Size(136, 135);
            this.picFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picFoto.TabIndex = 14;
            this.picFoto.TabStop = false;
            // 
            // lblSexo
            // 
            this.lblSexo.AutoSize = true;
            this.lblSexo.Location = new System.Drawing.Point(301, 150);
            this.lblSexo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSexo.Name = "lblSexo";
            this.lblSexo.Size = new System.Drawing.Size(43, 17);
            this.lblSexo.TabIndex = 15;
            this.lblSexo.Text = "Sexo:";
            // 
            // txtSexo
            // 
            this.txtSexo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSexo.Location = new System.Drawing.Point(305, 169);
            this.txtSexo.Margin = new System.Windows.Forms.Padding(4);
            this.txtSexo.Name = "txtSexo";
            this.txtSexo.Size = new System.Drawing.Size(40, 22);
            this.txtSexo.TabIndex = 16;
            // 
            // lblTeclas
            // 
            this.lblTeclas.AutoSize = true;
            this.lblTeclas.Location = new System.Drawing.Point(17, 336);
            this.lblTeclas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTeclas.Name = "lblTeclas";
            this.lblTeclas.Size = new System.Drawing.Size(257, 17);
            this.lblTeclas.TabIndex = 17;
            this.lblTeclas.Text = "F2 - Evento Change / F3 - Evento Enter";
            // 
            // btnRecortar
            // 
            this.btnRecortar.Location = new System.Drawing.Point(586, 127);
            this.btnRecortar.Margin = new System.Windows.Forms.Padding(4);
            this.btnRecortar.Name = "btnRecortar";
            this.btnRecortar.Size = new System.Drawing.Size(100, 54);
            this.btnRecortar.TabIndex = 18;
            this.btnRecortar.Text = "Recortar";
            this.btnRecortar.UseVisualStyleBackColor = true;
            // 
            // btnCopiar
            // 
            this.btnCopiar.Location = new System.Drawing.Point(586, 189);
            this.btnCopiar.Margin = new System.Windows.Forms.Padding(4);
            this.btnCopiar.Name = "btnCopiar";
            this.btnCopiar.Size = new System.Drawing.Size(100, 54);
            this.btnCopiar.TabIndex = 19;
            this.btnCopiar.Text = "Copiar";
            this.btnCopiar.UseVisualStyleBackColor = true;
            // 
            // btnColar
            // 
            this.btnColar.Location = new System.Drawing.Point(586, 250);
            this.btnColar.Margin = new System.Windows.Forms.Padding(4);
            this.btnColar.Name = "btnColar";
            this.btnColar.Size = new System.Drawing.Size(100, 54);
            this.btnColar.TabIndex = 20;
            this.btnColar.Text = "Colar";
            this.btnColar.UseVisualStyleBackColor = true;
            // 
            // btnOcultar
            // 
            this.btnOcultar.Location = new System.Drawing.Point(562, 312);
            this.btnOcultar.Margin = new System.Windows.Forms.Padding(4);
            this.btnOcultar.Name = "btnOcultar";
            this.btnOcultar.Size = new System.Drawing.Size(124, 54);
            this.btnOcultar.TabIndex = 21;
            this.btnOcultar.Text = "Ocultar Teclas de Atalho";
            this.btnOcultar.UseVisualStyleBackColor = true;
            // 
            // btnMostrar
            // 
            this.btnMostrar.Location = new System.Drawing.Point(562, 371);
            this.btnMostrar.Margin = new System.Windows.Forms.Padding(4);
            this.btnMostrar.Name = "btnMostrar";
            this.btnMostrar.Size = new System.Drawing.Size(124, 54);
            this.btnMostrar.TabIndex = 22;
            this.btnMostrar.Text = "Mostrar Teclas de Atalho";
            this.btnMostrar.UseVisualStyleBackColor = true;
            // 
            // lblMostrar2
            // 
            this.lblMostrar2.AutoSize = true;
            this.lblMostrar2.Location = new System.Drawing.Point(13, 448);
            this.lblMostrar2.Name = "lblMostrar2";
            this.lblMostrar2.Size = new System.Drawing.Size(0, 17);
            this.lblMostrar2.TabIndex = 24;
            // 
            // btnImagem
            // 
            this.btnImagem.Location = new System.Drawing.Point(196, 224);
            this.btnImagem.Name = "btnImagem";
            this.btnImagem.Size = new System.Drawing.Size(109, 53);
            this.btnImagem.TabIndex = 25;
            this.btnImagem.Text = "Imagem";
            this.btnImagem.UseVisualStyleBackColor = true;
            // 
            // frmEventos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 483);
            this.Controls.Add(this.btnImagem);
            this.Controls.Add(this.lblMostrar2);
            this.Controls.Add(this.btnMostrar);
            this.Controls.Add(this.btnOcultar);
            this.Controls.Add(this.btnColar);
            this.Controls.Add(this.btnCopiar);
            this.Controls.Add(this.btnRecortar);
            this.Controls.Add(this.lblTeclas);
            this.Controls.Add(this.txtSexo);
            this.Controls.Add(this.lblSexo);
            this.Controls.Add(this.picFoto);
            this.Controls.Add(this.lblOK);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.lblIdade);
            this.Controls.Add(this.txtIdade);
            this.Controls.Add(this.mskdataNascimento);
            this.Controls.Add(this.lbldataNascimento);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lbleventoEnter);
            this.Controls.Add(this.lblMostrar);
            this.Controls.Add(this.txtChange);
            this.Controls.Add(this.lblChange);
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmEventos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exemplos de Eventos e Métodos";            
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblChange;
        private System.Windows.Forms.TextBox txtChange;
        private System.Windows.Forms.Label lblMostrar;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lbleventoEnter;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lbldataNascimento;
        private System.Windows.Forms.MaskedTextBox mskdataNascimento;
        private System.Windows.Forms.Label lblIdade;
        private System.Windows.Forms.TextBox txtIdade;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label lblOK;
        private System.Windows.Forms.PictureBox picFoto;
        private System.Windows.Forms.Label lblSexo;
        private System.Windows.Forms.TextBox txtSexo;
        private System.Windows.Forms.Label lblTeclas;
        private System.Windows.Forms.Button btnRecortar;
        private System.Windows.Forms.Button btnCopiar;
        private System.Windows.Forms.Button btnColar;
        private System.Windows.Forms.Button btnOcultar;
        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.Label lblMostrar2;
        private System.Windows.Forms.Button btnImagem;
    }
}

