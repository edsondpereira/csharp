﻿namespace Eventos_Exemplos
{
    partial class frmEventos
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblChange = new System.Windows.Forms.Label();
            this.txtChange = new System.Windows.Forms.TextBox();
            this.lblMostrar = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lbleventoEnter = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lbldataNascimento = new System.Windows.Forms.Label();
            this.mskdataNascimento = new System.Windows.Forms.MaskedTextBox();
            this.lblIdade = new System.Windows.Forms.Label();
            this.txtIdade = new System.Windows.Forms.TextBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.lblOK = new System.Windows.Forms.Label();
            this.picFoto = new System.Windows.Forms.PictureBox();
            this.lblSexo = new System.Windows.Forms.Label();
            this.txtSexo = new System.Windows.Forms.TextBox();
            this.lblTeclas = new System.Windows.Forms.Label();
            this.btnRecortar = new System.Windows.Forms.Button();
            this.btnCopiar = new System.Windows.Forms.Button();
            this.btnColar = new System.Windows.Forms.Button();
            this.btnOcultar = new System.Windows.Forms.Button();
            this.btnMostrar = new System.Windows.Forms.Button();
            this.lblMostrar2 = new System.Windows.Forms.Label();
            this.btnImagem = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).BeginInit();
            this.SuspendLayout();
            // 
            // lblChange
            // 
            this.lblChange.AutoSize = true;
            this.lblChange.Location = new System.Drawing.Point(12, 11);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(81, 13);
            this.lblChange.TabIndex = 0;
            this.lblChange.Text = "Evento Change";
            // 
            // txtChange
            // 
            this.txtChange.Location = new System.Drawing.Point(15, 27);
            this.txtChange.Name = "txtChange";
            this.txtChange.Size = new System.Drawing.Size(399, 20);
            this.txtChange.TabIndex = 1;
            this.txtChange.Click += new System.EventHandler(this.txtChange_Click);
            this.txtChange.TextChanged += new System.EventHandler(this.txtChange_TextChanged);
            // 
            // lblMostrar
            // 
            this.lblMostrar.AutoSize = true;
            this.lblMostrar.Location = new System.Drawing.Point(15, 292);
            this.lblMostrar.Name = "lblMostrar";
            this.lblMostrar.Size = new System.Drawing.Size(0, 13);
            this.lblMostrar.TabIndex = 2;
            // 
            // txtNome
            // 
            this.txtNome.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNome.Location = new System.Drawing.Point(18, 95);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(399, 20);
            this.txtNome.TabIndex = 4;
            // 
            // lbleventoEnter
            // 
            this.lbleventoEnter.AutoSize = true;
            this.lbleventoEnter.Location = new System.Drawing.Point(15, 59);
            this.lbleventoEnter.Name = "lbleventoEnter";
            this.lbleventoEnter.Size = new System.Drawing.Size(69, 13);
            this.lbleventoEnter.TabIndex = 3;
            this.lbleventoEnter.Text = "Evento Enter";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(17, 79);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(38, 13);
            this.lblNome.TabIndex = 5;
            this.lblNome.Text = "Nome:";
            // 
            // lbldataNascimento
            // 
            this.lbldataNascimento.AutoSize = true;
            this.lbldataNascimento.Location = new System.Drawing.Point(19, 122);
            this.lbldataNascimento.Name = "lbldataNascimento";
            this.lbldataNascimento.Size = new System.Drawing.Size(95, 13);
            this.lbldataNascimento.TabIndex = 7;
            this.lbldataNascimento.Text = "Dt de Nascimento:";
            // 
            // mskdataNascimento
            // 
            this.mskdataNascimento.Location = new System.Drawing.Point(20, 138);
            this.mskdataNascimento.Mask = "00/00/0000";
            this.mskdataNascimento.Name = "mskdataNascimento";
            this.mskdataNascimento.Size = new System.Drawing.Size(94, 20);
            this.mskdataNascimento.TabIndex = 8;
            this.mskdataNascimento.ValidatingType = typeof(System.DateTime);
            // 
            // lblIdade
            // 
            this.lblIdade.AutoSize = true;
            this.lblIdade.Location = new System.Drawing.Point(119, 122);
            this.lblIdade.Name = "lblIdade";
            this.lblIdade.Size = new System.Drawing.Size(37, 13);
            this.lblIdade.TabIndex = 10;
            this.lblIdade.Text = "Idade:";
            // 
            // txtIdade
            // 
            this.txtIdade.Location = new System.Drawing.Point(120, 138);
            this.txtIdade.Name = "txtIdade";
            this.txtIdade.Size = new System.Drawing.Size(99, 20);
            this.txtIdade.TabIndex = 9;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(41, 180);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(96, 42);
            this.btnOK.TabIndex = 11;
            this.btnOK.Text = "Evento Click";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // lblOK
            // 
            this.lblOK.AutoSize = true;
            this.lblOK.Location = new System.Drawing.Point(38, 225);
            this.lblOK.Name = "lblOK";
            this.lblOK.Size = new System.Drawing.Size(100, 13);
            this.lblOK.TabIndex = 12;
            this.lblOK.Text = "Confirma as opções";
            this.lblOK.Visible = false;
            // 
            // picFoto
            // 
            this.picFoto.Location = new System.Drawing.Point(260, 177);
            this.picFoto.Name = "picFoto";
            this.picFoto.Size = new System.Drawing.Size(154, 128);
            this.picFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picFoto.TabIndex = 14;
            this.picFoto.TabStop = false;
            // 
            // lblSexo
            // 
            this.lblSexo.AutoSize = true;
            this.lblSexo.Location = new System.Drawing.Point(226, 122);
            this.lblSexo.Name = "lblSexo";
            this.lblSexo.Size = new System.Drawing.Size(34, 13);
            this.lblSexo.TabIndex = 15;
            this.lblSexo.Text = "Sexo:";
            // 
            // txtSexo
            // 
            this.txtSexo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtSexo.Location = new System.Drawing.Point(229, 137);
            this.txtSexo.Name = "txtSexo";
            this.txtSexo.Size = new System.Drawing.Size(31, 20);
            this.txtSexo.TabIndex = 16;
            // 
            // lblTeclas
            // 
            this.lblTeclas.AutoSize = true;
            this.lblTeclas.Location = new System.Drawing.Point(13, 273);
            this.lblTeclas.Name = "lblTeclas";
            this.lblTeclas.Size = new System.Drawing.Size(196, 13);
            this.lblTeclas.TabIndex = 17;
            this.lblTeclas.Text = "F2 - Evento Change / F3 - Evento Enter";
            // 
            // btnRecortar
            // 
            this.btnRecortar.Location = new System.Drawing.Point(440, 103);
            this.btnRecortar.Name = "btnRecortar";
            this.btnRecortar.Size = new System.Drawing.Size(75, 44);
            this.btnRecortar.TabIndex = 18;
            this.btnRecortar.Text = "Recortar";
            this.btnRecortar.UseVisualStyleBackColor = true;
            this.btnRecortar.Click += new System.EventHandler(this.btnRecortar_Click);
            // 
            // btnCopiar
            // 
            this.btnCopiar.Location = new System.Drawing.Point(440, 154);
            this.btnCopiar.Name = "btnCopiar";
            this.btnCopiar.Size = new System.Drawing.Size(75, 44);
            this.btnCopiar.TabIndex = 19;
            this.btnCopiar.Text = "Copiar";
            this.btnCopiar.UseVisualStyleBackColor = true;
            this.btnCopiar.Click += new System.EventHandler(this.btnCopiar_Click);
            // 
            // btnColar
            // 
            this.btnColar.Location = new System.Drawing.Point(440, 203);
            this.btnColar.Name = "btnColar";
            this.btnColar.Size = new System.Drawing.Size(75, 44);
            this.btnColar.TabIndex = 20;
            this.btnColar.Text = "Colar";
            this.btnColar.UseVisualStyleBackColor = true;
            this.btnColar.Click += new System.EventHandler(this.btnColar_Click);
            // 
            // btnOcultar
            // 
            this.btnOcultar.Location = new System.Drawing.Point(422, 254);
            this.btnOcultar.Name = "btnOcultar";
            this.btnOcultar.Size = new System.Drawing.Size(93, 44);
            this.btnOcultar.TabIndex = 21;
            this.btnOcultar.Text = "Ocultar Teclas de Atalho";
            this.btnOcultar.UseVisualStyleBackColor = true;
            this.btnOcultar.Click += new System.EventHandler(this.btnOcultar_Click);
            // 
            // btnMostrar
            // 
            this.btnMostrar.Location = new System.Drawing.Point(422, 301);
            this.btnMostrar.Name = "btnMostrar";
            this.btnMostrar.Size = new System.Drawing.Size(93, 44);
            this.btnMostrar.TabIndex = 22;
            this.btnMostrar.Text = "Mostrar Teclas de Atalho";
            this.btnMostrar.UseVisualStyleBackColor = true;
            this.btnMostrar.Click += new System.EventHandler(this.btnMostrar_Click);
            // 
            // lblMostrar2
            // 
            this.lblMostrar2.AutoSize = true;
            this.lblMostrar2.Location = new System.Drawing.Point(10, 364);
            this.lblMostrar2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMostrar2.Name = "lblMostrar2";
            this.lblMostrar2.Size = new System.Drawing.Size(0, 13);
            this.lblMostrar2.TabIndex = 24;
            // 
            // btnImagem
            // 
            this.btnImagem.Location = new System.Drawing.Point(147, 182);
            this.btnImagem.Margin = new System.Windows.Forms.Padding(2);
            this.btnImagem.Name = "btnImagem";
            this.btnImagem.Size = new System.Drawing.Size(82, 43);
            this.btnImagem.TabIndex = 25;
            this.btnImagem.Text = "Imagem";
            this.btnImagem.UseVisualStyleBackColor = true;
            this.btnImagem.MouseMove += new System.Windows.Forms.MouseEventHandler(this.btnImagem_MouseMove);
            // 
            // frmEventos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 392);
            this.Controls.Add(this.btnImagem);
            this.Controls.Add(this.lblMostrar2);
            this.Controls.Add(this.btnMostrar);
            this.Controls.Add(this.btnOcultar);
            this.Controls.Add(this.btnColar);
            this.Controls.Add(this.btnCopiar);
            this.Controls.Add(this.btnRecortar);
            this.Controls.Add(this.lblTeclas);
            this.Controls.Add(this.txtSexo);
            this.Controls.Add(this.lblSexo);
            this.Controls.Add(this.picFoto);
            this.Controls.Add(this.lblOK);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.lblIdade);
            this.Controls.Add(this.txtIdade);
            this.Controls.Add(this.mskdataNascimento);
            this.Controls.Add(this.lbldataNascimento);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lbleventoEnter);
            this.Controls.Add(this.lblMostrar);
            this.Controls.Add(this.txtChange);
            this.Controls.Add(this.lblChange);
            this.KeyPreview = true;
            this.Name = "frmEventos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exemplos de Eventos e Métodos";
            this.Load += new System.EventHandler(this.frmEventos_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmEventos_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.frmEventos_KeyPress);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.frmEventos_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblChange;
        private System.Windows.Forms.TextBox txtChange;
        private System.Windows.Forms.Label lblMostrar;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lbleventoEnter;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lbldataNascimento;
        private System.Windows.Forms.MaskedTextBox mskdataNascimento;
        private System.Windows.Forms.Label lblIdade;
        private System.Windows.Forms.TextBox txtIdade;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Label lblOK;
        private System.Windows.Forms.PictureBox picFoto;
        private System.Windows.Forms.Label lblSexo;
        private System.Windows.Forms.TextBox txtSexo;
        private System.Windows.Forms.Label lblTeclas;
        private System.Windows.Forms.Button btnRecortar;
        private System.Windows.Forms.Button btnCopiar;
        private System.Windows.Forms.Button btnColar;
        private System.Windows.Forms.Button btnOcultar;
        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.Label lblMostrar2;
        private System.Windows.Forms.Button btnImagem;
    }
}

