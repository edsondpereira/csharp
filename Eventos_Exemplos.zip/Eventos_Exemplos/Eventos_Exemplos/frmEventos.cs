﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eventos_Exemplos
{
    public partial class frmEventos : Form
    {
        public frmEventos()
        {
            InitializeComponent();
        }

        private void txtChange_TextChanged(object sender, EventArgs e)
        {
            lblMostrar.Text = txtChange.Text;

            if (txtChange.Text.Length > 0)
            {
                lblMostrar2.Text = "Este é o " + txtChange.Text.Length + "º caracter!";
            }
            else
            {
                lblMostrar2.Text="";
            }
        }

        private void frmEventos_Load(object sender, EventArgs e)
        {

        }

        private void frmEventos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == 13) // Se a tecla pressionada for Enter
            {
                e.Handled = true;
                SendKeys.Send("{tab}");
            }
            // 48 até 57 -> 0 até o 9  
            // 13 -> Enter / 27 -> Esc / 8 -> BackSpace / 128 -> Delete
            // 65 -> A
            // Deixar a propriedade KeyPreview do formulário como True
        }

        private void frmEventos_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F2)
            {
                txtChange.Focus();
            }

            if (e.KeyCode == Keys.F3)
            {
                txtNome.Focus();
            }

            if(e.KeyCode == Keys.F4)
            {
                Process.Start("calc.exe");
            }

            if (e.KeyCode == Keys.F5)
            {
                Process.Start("https://www.sp.senac.br");
            }

        }

        private void btnImagem_MouseMove(object sender, MouseEventArgs e)
        {
            string caminho = System.AppDomain.CurrentDomain.BaseDirectory.ToString();
            picFoto.Image = Image.FromFile(caminho + "\\linguagens.png");
        }

        private void frmEventos_MouseMove(object sender, MouseEventArgs e)
        {
            picFoto.Image = null;
        }

        private void btnRecortar_Click(object sender, EventArgs e)
        {
            txtChange.Cut(); // Recorta o conteúdo que está selecionado
        }

        private void btnCopiar_Click(object sender, EventArgs e)
        {
            txtChange.Copy(); // Copia o conteúdo que está selecionado
        }

        private void btnColar_Click(object sender, EventArgs e)
        {
            txtNome.Paste(); // Cola (coloca) nesta caixa o texto recortado ou copiado
        }

        private void btnOcultar_Click(object sender, EventArgs e)
        {
            lblTeclas.Visible= false;
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            lblTeclas.Visible = true;
        }

        private void txtChange_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Existem dados ditados, você quer realmente apagar?","Dados",MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                txtChange.Clear();
                txtNome.Clear();
                mskdataNascimento.Clear();
                txtIdade.Clear();
                txtSexo.Clear();
            }
            
        }
    }
}
