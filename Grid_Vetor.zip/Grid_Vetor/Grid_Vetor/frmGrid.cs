﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Grid_Vetor
{
    public partial class frmGrid : Form
    {
        public frmGrid()
        {
            InitializeComponent();
        }

        private void btnPreencher_Click(object sender, EventArgs e)
        {
            clsPessoa[] pessoas = new clsPessoa[]
            {
                new clsPessoa { codigo = 1, nome = "João", email = "joao@example.com" },
                new clsPessoa { codigo = 2, nome = "Maria", email = "maria@example.com" },
                new clsPessoa { codigo = 3, nome = "Pedro", email = "pedro@example.com" }
            };

            var resultado = pessoas.Where(p => p.nome.Contains(txtNome.Text)).ToArray();

            dgvDados.DataSource = pessoas.ToList();
        }

        private void dgvDados_DoubleClick(object sender, EventArgs e)
        {
            txtCodigo.Text= dgvDados[0, dgvDados.CurrentRow.Index].Value.ToString();
            txtNome.Text = dgvDados[1, dgvDados.CurrentRow.Index].Value.ToString();
            txtEmail.Text = dgvDados[2, dgvDados.CurrentRow.Index].Value.ToString();
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
