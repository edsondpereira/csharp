﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastro_Classe
{
    internal class clsPessoa
    {
        private int codigo;
        private string nome;
        private string endereco;
        private string cidade;
        private string uf;
        private string cpf;
        private string rg;
        private string CNPJ;
        private string InscricaoEstadual;
        private string email;
        private DateTime dataCadastro;

        
    }
}
